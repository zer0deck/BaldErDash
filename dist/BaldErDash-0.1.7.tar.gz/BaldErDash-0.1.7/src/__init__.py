from .main import Game

__all__ = ["Game"]
