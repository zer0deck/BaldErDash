# BaldErDash

[BaldErDash](github.com/zer0deck/BaldErDash/) is some kind of Pyhton gamedev expience. This is a demo Python physics engine and much more just a [pygame](https://github.com/pygame/pygame) lib practice.

Play with fun, hope you enjoy this trash!)

[![GitHub release (latest by date)](https://img.shields.io/github/v/release/zer0deck/BaldErDash)](https://github.com/zer0deck/BaldErDash/releases) [![Build Status](https://img.shields.io/github/workflow/status/zer0deck/BaldErDash/master)](https://github.com/zer0deck/BaldErDash/actions/workflows/package-test.yml)  ![](https://visitor-badge.laobi.icu/badge?page_id=zer0deck.BaldErDash)

# Instalation

```
creating package is in progress. I'll publish it pip with the first release
```

# License

[![EULA Licence](https://img.shields.io/badge/Distribution-Unity%20Assets%20Store%20EULA-yellow)](https://unity3d.com/legal/as_terms) [![Engine License](https://img.shields.io/badge/Engine%20License-LGNU-yellow)](https://github.com/zer0deck/BaldErDash/blob/master/LICENSE) [![In-game Content License](https://img.shields.io/badge/Ingame%20Content%20License-CC%20BY--SA%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-sa/4.0/) [![Assets License](https://img.shields.io/badge/Assets%20License-CC%20BY--NC--ND%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc-nd/4.0/)

You may see three different licenses depending on the folder you open and get very scared.

This lib is distibuted under [Lesser GNU GENERAL PUBLIC License](https://www.gnu.org/licenses/gpl-3.0.html). Do whatever you want, just want to ask You to indicate [me](github.com/zer0deck) as an original author.

Although the physics engine and its code are licensed under the [LGNU license](https://www.gnu.org/licenses/gpl-3.0.html) in accordance with pygame policy and my own view of my work, I consider levels and other in-game content deeply my intellectual property and are limited by the [CC BY-SA License](https://creativecommons.org/licenses/by-sa/4.0/).

Assets made by [Danil Chernyaev](https://www.behance.net/danilche9919f3) and distributed under [EULA License](https://unity3d.com/legal/as_terms) by [Unity Asset Store](https://assetstore.unity.com/) for me as the end-user. This assets are now under [CC BY-NC-ND License](https://creativecommons.org/licenses/by-nc-nd/4.0/)

> Maybe I'll make more changes in licensing later.






